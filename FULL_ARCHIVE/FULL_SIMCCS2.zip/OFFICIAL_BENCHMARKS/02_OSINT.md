# OSINT Benchmark — SIMCCS2

**Upstream:** https://github.com/SimCCS/simccs2

Public-record information collected about upstream project:

- GitHub stars: see upstream
- License: Apache 2.0
- Last commit: check upstream
- Known CVEs: check NVD

Status: PENDING systematic collection.
